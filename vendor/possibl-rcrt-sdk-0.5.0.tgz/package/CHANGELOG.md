# @possibl/rcrt-sdk — Changelog

All notable changes are documented here. Follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) + [semver](https://semver.org/).

## Unreleased

Address grammar alignment with the Go runtime (`internal/llm/address.go`).

### Changed (breaking)

- **`parseModelAddress` / `formatModelAddress`** now mirror the Go grammar
  exactly:
  - Accept the 2-segment `route/model` form (provider empty) in addition to the
    3-segment `route/provider/model` form.
  - Strip an optional case-insensitive `rcrt/` prefix before parsing.
  - **Reject** any address containing `//` (the legacy `route//model` form).
    The previous SDK accepted `//` and `formatModelAddress` re-emitted it; the
    Go runtime now rejects `//`, so SDK callers that wrote `//` addresses must
    switch to `route/model` or `route/provider/model`.
  - `formatModelAddress` renders an empty provider as `route/model` (never
    `route//model`).

### Added

- **`stripRCRTPrefix`** helper and **`RCRT_PREFIX`** constant, exported from the
    package root.

## 0.5.0 — 2026-06-22

Workspace membership + invitation management, plus self-serve signup and open-enrollment join. Additive only — no breaking changes.

### Added

- **`client.members`** — `MembersModule`: workspace member + invitation
  lifecycle against `/v1/tenants/{id}/members` and `/v1/tenants/{id}/invitations`.
  Methods: `list`, `add`, `updateRole`, `remove`, `listInvitations`, `invite`,
  `cancelInvitation`. Creating an invitation also sends the invite email
  server-side (no separate resend endpoint — re-create to resend).
- **`TenantMember`**, **`TenantInvitation`** types, exported from the package root.
- **`auth.signup()`** — self-serve first-workspace provisioning
  (`POST /v1/auth/signup`). Idempotent: returns the existing personal workspace
  (200) when one already exists, 201 on creation. Call when `listTenants()` is
  empty after first sign-in.
- **`auth.joinTenant(tenantId)`** — open-enrollment self-join
  (`POST /v1/tenants/{id}/join`). Any authenticated user may join a tenant that
  has opted into `tenants.auto_enroll_role`; idempotent. No `X-Tenant-ID` header.
- **`TenantMembership`** type, exported from the package root.

## 0.4.0 — 2026-06-18

Chat file attachments (route-agnostic multimodal).

### Added

- **`SendChatRequest.attachments`** — optional `ChatAttachmentRef[]`
  (`{ file_breadcrumb_id, mime_type? }`). Upload via `client.files.upload(...)`
  first, then pass the returned `FileRecord.id` as `file_breadcrumb_id`. The
  server resolves the `gs://` URI + mime type and delivers the file to a
  file-capable agent. Omitting it leaves the text-only body unchanged.
- **`ChatAttachmentRef`** type, exported from the package root.

## 0.3.0 — 2026-06-17

The unified LLM model addressing release. LLM selection is now a single
canonical `route/provider/model` address stored in the agent breadcrumb's
`engine_config.model` (see `docs/design/LLM_PROVIDER_MODEL_RESOLUTION.md`).
There is no runtime tier indirection, no org override layer, and no fallbacks.

### Removed (breaking)

- **`org.getLLMTiers` / `org.upsertLLMTier` / `org.deleteLLMTier`** and the
  `OrgLLMTier` type — the `/v1/orgs/{org}/llm-tiers` endpoints and the
  `org_intelligence_tier_overrides` layer are gone. Tiers are authoring sugar
  expanded to a concrete address at publish time; there is no org tier override.
- **`OrgLLMProvider.fallback_for_id`** — `org_llm_providers` is now purely a
  credential store keyed by route. `is_default` is retained only as a
  convenience flag for credential listing and does NOT influence resolution.
  There is no `fallback` role and no fallback behaviour (fail loudly instead).

### Added

- **`EngineConfig` / `ModelAddress`** types plus `parseModelAddress`,
  `formatModelAddress`, `isTierAddress`, and `ROUTE_TIER` — the typed mirror of
  the Go `pkg/rcrt/types.go` `EngineConfig` and `internal/llm/address.go`
  `ModelAddress`.
- **`breadcrumbs.updateAgentEngineConfig(id, modelAddress, version)`** — typed
  convenience that PATCHes an agent breadcrumb's `engine_config.model` to a
  canonical address while preserving the rest of `content`.

### Migration

- `org.listLLMProviders` is unchanged (credential listing).
- Replace any tier reads/writes with the per-agent breadcrumb address via
  `breadcrumbs.updateAgentEngineConfig`.

## 0.2.0 — 2026-06-12

The convergence release: everything the MSP console reached past the SDK for is now typed surface. `@possibl/rcrt-api` consumers should migrate to this package — the legacy package is being deprecated.

### Added

- **`client.request(path, options)`** — public, typed escape hatch with the client's auth + tenant headers, 401/409/429 retry handling and error envelope. Apps are never blocked on an SDK release for a new gateway endpoint. `options.body` takes a plain object (SDK serialises); `options.rawBody` takes FormData/binary; `options.query` appends search params.
- **`client.forTenant(tenantId)`** — cached, permanently-bound per-tenant client instances for parallel fleet fan-out. Replaces the mutate-one-client `setTenantId` pattern for multi-workspace reads (no shared-client races, no request serialisation).
- **`client.marketplace`** — bundle catalogue + install lifecycle: `listBundles`, `getBundle`, `bundleStatus`, `listInstalledBundles`, `installBundle`, `updateBundle`, `repairBundle`, `pruneBundle`, `uninstallBundle`. Typed `BundleStatus` / `BundleItemResult` wire shapes matching the gateway's `/v1/marketplace/*` routes.
- **`client.org`** — org admin surface: `get`, `listMembers`, `listTenants`, `createTenant`, `createCustomerOrg`, plus intelligence-tier overrides (`getLLMTiers`, `upsertLLMTier`, `deleteLLMTier`, `listLLMProviders`).
- **`client.files`** — multipart `upload` (isomorphic `FormData`, no deps), `list`, `get`, `downloadUrl`, `getText`, `delete`.
- **`client.chat`** — session utilities: `sessionBreadcrumbs`, `sessionParticipants`, `addSessionParticipant`, `removeSessionParticipant`; and `listAgents()` agent discovery (`interpret:promptable` + `interface:chat` filtering).
- Internal fetch: `rawBody` request option for non-JSON payloads.

### Notes

- `chat.send` already supported `extra_tags` + `target_agent` — no change needed for App Control grounding tags.
- No breaking changes; 0.1.x consumers upgrade cleanly.

## 0.1.0-alpha.1 — 2026-04-23

First publish. Breaking changes are expected during the `alpha` line — pin exact versions. Do not use in production until `0.1.0` stable.

### Included

- `RcrtClient` with auth, chat (send + stream), breadcrumbs (CRUD + tag query + semantic search), service grants, cards, identity modules.
- Pluggable `TokenProvider` interface — SDK never touches Firebase / Auth0 / Clerk directly.
- Pluggable `EventSource` — React Native consumers inject `react-native-sse`; browser + Node 18+ use native.
- Typed error envelope via `ApiError.detail.code` / `KnownErrorCode`. Accepts both the canonical `{error: {code, message, details}}` and legacy `{error: "string"}` shapes during the migration window.
- Domain types (`Card`, `Breadcrumb`, `Row`, `ChartSpec`, ...) under the main export.
- OpenAPI-generated types (`paths`, `operations`, `components`) under `@possibl/rcrt-sdk/generated` for raw fetch-level type safety.

### Known gaps

- No integration test suite against a live backend yet. Smoke tests (9/9) cover the mock surface. Integration harness is queued.
- The backend's error-envelope migration is in progress (tracked in `packages/docs/guides/07-error-handling.md`). Any handler still returning `{error: "string"}` is normalised by the SDK's `parseErrorBody`.
- React hooks / a card renderer are deliberately out of scope. See `packages/docs/recipes/react.md` for copy-pasteable patterns.

### Support matrix

| Runtime | Supported |
| --- | --- |
| Browser (Chrome 103+, Firefox 102+, Safari 16+) | Yes |
| Node 18+ | Yes |
| React Native + `react-native-sse` polyfill | Yes |
| Deno 1.40+ | Untested, should work |
| Bun 1.0+ | Untested, should work |
