# @possibl/rcrt-app-kit — Changelog

All notable changes are documented here. Follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) + [semver](https://semver.org/).

## 0.3.0 — 2026-06-13

The native release: a `@possibl/rcrt-app-kit/native` subpath that interprets the
**same** `defineApp`/`defineSection` registry the web `<RcrtApp>` consumes, but
renders with React Native + Expo Router. Fully additive — `core`, `shell`, `ui`
and every web consumer (the MSP console) are unchanged.

### `native` — new subpath export (`@possibl/rcrt-app-kit/native`)

- **Same registry, native renderer.** `defineSection`/`defineApp`/`defineForm`
  and every registry type are re-exported UNCHANGED from the platform-agnostic
  `shell/registry` module the web shell uses — reusing them is the proof the
  registry is platform-agnostic. `core` is imported untouched.
- **`<RcrtNativeProvider>`** — root-layout wiring: publishes the
  `interpret:ui-manifest` (flagged `platform: 'native'`), provides the
  AsyncStorage-backed SWR cache + theme, and consumes advisor-driven navigation
  through Expo Router (route push).
- **Navigation maps to Expo Router:** `<RcrtTabs>` derives a bottom-tab layout
  from the sections; `<SectionScreen>` renders a section (with its `tabs` as an
  in-screen segmented control + page-context grounding); `<RecordScreen>`
  renders a record route as a deep-linkable stack screen; `<AdvisorScreen>` is
  a chat-first advisor modal.
- **Advisor on native, honest about spotlight.** `<AdvisorScreen>` +
  `NativeChat` (RN, streams via the SDK's `react-native-sse` EventSource seam +
  `useHeaderAuth`) chat with the agent, self-provision the paired bundle and
  attach `app-page:`/`app-context:` grounding tags. The **spotlight overlay is
  web-only** — the native `defineAnchor` is a pass-through and the native
  manifest sets `capabilities.spotlight = false` rather than faking it.
  Advisor-driven **navigation** works on native.
- **`asyncStorageAdapter(AsyncStorage)`** — the `core` `StorageAdapter` is
  synchronous (paint-from-snapshot during first render); this bridges
  AsyncStorage with a sync-over-memory map hydrated on boot. AsyncStorage is a
  /native peer dep and is NOT hard-imported by `core`.
- **Native UI primitives + theme** — `Card`/`Badge`/`Button`/`EmptyState`/
  `SkeletonPanel`/`StatCard`/`UpdatedAgo`/`SectionPage` rendering `View`/`Text`,
  same names + prop shapes as `/ui`; `RcrtThemeProvider`/`useTheme` carry the
  `--rcrt-*` palette as RN tokens (brand by passing `theme` overrides).
- **`useAppForm`** (native) — advisor form-prefill consumption against the
  native advisor bus, same contract as the web hook.

### `shell` — additive

- `buildManifest(app, { platform: 'native' })` and a matching optional argument
  on `ensureManifestPublished` add `app.platform = 'native'` + a `capabilities`
  honesty block (`spotlight: false, navigation: true`). The default (web) output
  is **byte-identical** to 0.2 — same shape, same djb2 hash — so the console's
  published manifest is unaffected.

### Peer deps

- New OPTIONAL peers for `/native`: `react-native`, `expo`, `expo-router`,
  `@react-native-async-storage/async-storage`, `react-native-sse`.
  `react-dom`/`react-router-dom` are now also optional (web `/shell`+`/ui` only),
  so neither platform's consumer is warned about the other's deps.

## 0.2.0 — 2026-06-13

Hardening release from the MSP-console dogfood: the console migrated onto 0.1.0
successfully but had to work around six gaps. All six are now first-class,
additive APIs — **fully backward compatible**: a 0.1.0 app compiles and behaves
identically without touching its config.

### `shell` — new APIs

- **Nested / record routes (`RecordPage`).** A section can declare child
  `records` — deep-linkable detail views with a path param
  (`{ customer: { path: 'customers/:id', component: CustomerRecord } }` →
  `/fleet/customers/:id`). Each record route gets its own component
  (`RecordComponentProps` = `{ params, section, record, close }`), manifest
  route entry, anchors/forms, page context and active-state. The parent
  section stays highlighted in the nav while a record is open
  (`keepParentActive`, default `true`). Routing is no longer first-path-segment
  only — the design doc's `RecordPage` notion.
- **Dynamic / async page-context resolver.** `context` (on a section or a
  record route) may now return `string | null | Promise<string | null>`, and
  `SectionRouteState` carries `params`. The shell awaits the promise and sets
  the context when it resolves (stale-navigation-guarded) — so a record route
  that only has an `:id` in the URL can ground the advisor with the resolved
  name. New exported types: `ContextResolver`, `PageContext`.
- **Chromeless route flag.** `chrome?: boolean | { header?, nav? }` on a section
  or record route. `false` is a full-bleed takeover (no shell header, no nav
  rail); the object form suppresses each independently. The advisor dock +
  overlay stay available. New exported type: `ChromeConfig`.
- **Nav-item badges.** `SectionConfig.navBadge?: ComponentType` renders a live
  count/dot on a nav item (it's a component, so it can use hooks). Styled via
  the ready-made `.rcrt-nav-badge` / `.rcrt-nav-badge-dot` classes.
- **Multiple ungrouped nav blocks.** `navSlot?: 'top' | 'bottom'` (on a section
  or a `NavLink`) pins an entry into its own ungrouped block at the top/bottom
  of the rail — so a home item and a settings item can both be ungrouped AND
  separated. Entries without `navSlot` keep the 0.1 grouping behavior exactly.
- **Grounding-tag hook.** `advisor.groundingTags?: (base: string[]) => string[]`
  contributes extra tags (e.g. a legacy `console-page:` mirror) to every advisor
  message, so apps don't wrap `sendChat` in a `renderChat` seam just for tags.

### Docs / examples

- New `examples/record-route` proves the record route + chromeless takeover +
  nav badge + multi-ungrouped nav + grounding hook in one pure-config app.

## 0.1.0 — 2026-06-12

First release — the React application framework extracted and generalized from the production MSP console, rebuilt on `@possibl/rcrt-sdk` 0.2.0.

### `core` (platform-agnostic, React-Native-safe)

- `StorageAdapter` seam + `memoryStorageAdapter` (web `localStorageAdapter` ships in `shell`).
- `SwrCache` / `SwrProvider` / `useCached` — stale-while-revalidate snapshot cache with scoped keys (user/tenant/schema-version), TTL, prefix invalidation and quota-safe persistence.
- `withTenant` / `fanout` — fleet fan-out on the SDK's `forTenant()` per-tenant clients, with per-workspace failure collection (feeds `FanoutWarning`).
- Breadcrumb schema helpers: `queryTagged` / `createTagged` / `patchContent` / `upsertByName`, plus `defineSchema` — a typed handle binding tag + `schema_version` + content type.

### `shell` (web)

- The **Section Registry**: `defineSection` / `defineAnchor` / `defineForm` / `defineApp`. One declaration; router, nav, manifest, anchors, context and form plumbing are derived.
- `<RcrtApp>` — nav rail + header + section rendering + advisor surface, all from the registry. Auth is a seam (bring a configured `RcrtClient`).
- Hash-idempotent `interpret:ui-manifest` publication derived from the registry (djb2, matching `tool-ui-manifest`).
- Anchors as components (`handle.Anchor`) with registry-assigned namespaced ids — undeclared anchors are unrenderable, unreferenced ones are unused variables.
- Forms with namespaced ids (`{section}.{key}`) + structured `intent`/`entity`/`distinguishFrom` semantics + field specs; `useAppForm` consumes advisor prefills with validation.
- Page context computed by the shell on every location change (`{id}:{tab}` default, `context()` override).
- `SectionPage` chrome: refresh + `UpdatedAgo` + error banner + `FanoutWarning` ceremony rendered by the shell.
- Advisor surface: `AdvisorDock` (brandable name/tagline/suggestions, ⌘J, per-tenant session persistence, paired-bundle self-provisioning), `GuideOverlay` spotlight, the advisor bus (`useAdvisor`, `guideTo`, auto-fire guard), and a built-in `MinimalChat` (swap via `advisor.renderChat`).

### `ui` (web)

- Primitives: `Card`, `StatCard`, `Badge`, `Button`, `Tabs`, `PageHeader`, `DataTable`, `EmptyState`, `Skeleton`, `SkeletonPanel`, `UpdatedAgo`, `FanoutWarning`, `Modal`, `Drawer` + a minimal inline icon set.
- Design tokens as `--rcrt-*` CSS variables (`styles.css`) with a neutral premium-dark default theme. No Tailwind, framer-motion or icon-library dependencies.

### Known gaps (deliberate, tracked for 0.2)

- Registry `data` loaders are not yet auto-wrapped in `useCached` (sections call `useCached` + pass the result to `SectionPage cache=`).
- Form field specs use a lightweight structural type, not zod schemas.
- Dev-mode anchor mount overlay + generated CI coverage check not yet included.
- No native (`/native`) shell yet — `core` is RN-safe by construction.
