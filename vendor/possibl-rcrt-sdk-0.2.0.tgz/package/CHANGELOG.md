# @possibl/rcrt-sdk — Changelog

All notable changes are documented here. Follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) + [semver](https://semver.org/).

## 0.2.0 — 2026-06-12

The convergence release: everything the MSP console reached past the SDK for is now typed surface. `@possibl/rcrt-api` consumers should migrate to this package — the legacy package is being deprecated.

### Added

- **`client.request(path, options)`** — public, typed escape hatch with the client's auth + tenant headers, 401/409/429 retry handling and error envelope. Apps are never blocked on an SDK release for a new gateway endpoint. `options.body` takes a plain object (SDK serialises); `options.rawBody` takes FormData/binary; `options.query` appends search params.
- **`client.forTenant(tenantId)`** — cached, permanently-bound per-tenant client instances for parallel fleet fan-out. Replaces the mutate-one-client `setTenantId` pattern for multi-workspace reads (no shared-client races, no request serialisation).
- **`client.marketplace`** — bundle catalogue + install lifecycle: `listBundles`, `getBundle`, `bundleStatus`, `listInstalledBundles`, `installBundle`, `updateBundle`, `repairBundle`, `pruneBundle`, `uninstallBundle`. Typed `BundleStatus` / `BundleItemResult` wire shapes matching the gateway's `/v1/marketplace/*` routes.
- **`client.org`** — org admin surface: `get`, `listMembers`, `listTenants`, `createTenant`, `createCustomerOrg`, plus intelligence-tier overrides (`getLLMTiers`, `upsertLLMTier`, `deleteLLMTier`, `listLLMProviders`).
- **`client.files`** — multipart `upload` (isomorphic `FormData`, no deps), `list`, `get`, `downloadUrl`, `getText`, `delete`.
- **`client.chat`** — session utilities: `sessionBreadcrumbs`, `sessionParticipants`, `addSessionParticipant`, `removeSessionParticipant`; and `listAgents()` agent discovery (`interpret:promptable` + `interface:chat` filtering).
- Internal fetch: `rawBody` request option for non-JSON payloads.

### Notes

- `chat.send` already supported `extra_tags` + `target_agent` — no change needed for App Control grounding tags.
- No breaking changes; 0.1.x consumers upgrade cleanly.

## 0.1.0-alpha.1 — 2026-04-23

First publish. Breaking changes are expected during the `alpha` line — pin exact versions. Do not use in production until `0.1.0` stable.

### Included

- `RcrtClient` with auth, chat (send + stream), breadcrumbs (CRUD + tag query + semantic search), service grants, cards, identity modules.
- Pluggable `TokenProvider` interface — SDK never touches Firebase / Auth0 / Clerk directly.
- Pluggable `EventSource` — React Native consumers inject `react-native-sse`; browser + Node 18+ use native.
- Typed error envelope via `ApiError.detail.code` / `KnownErrorCode`. Accepts both the canonical `{error: {code, message, details}}` and legacy `{error: "string"}` shapes during the migration window.
- Domain types (`Card`, `Breadcrumb`, `Row`, `ChartSpec`, ...) under the main export.
- OpenAPI-generated types (`paths`, `operations`, `components`) under `@possibl/rcrt-sdk/generated` for raw fetch-level type safety.

### Known gaps

- No integration test suite against a live backend yet. Smoke tests (9/9) cover the mock surface. Integration harness is queued.
- The backend's error-envelope migration is in progress (tracked in `packages/docs/guides/07-error-handling.md`). Any handler still returning `{error: "string"}` is normalised by the SDK's `parseErrorBody`.
- React hooks / a card renderer are deliberately out of scope. See `packages/docs/recipes/react.md` for copy-pasteable patterns.

### Support matrix

| Runtime | Supported |
| --- | --- |
| Browser (Chrome 103+, Firefox 102+, Safari 16+) | Yes |
| Node 18+ | Yes |
| React Native + `react-native-sse` polyfill | Yes |
| Deno 1.40+ | Untested, should work |
| Bun 1.0+ | Untested, should work |
