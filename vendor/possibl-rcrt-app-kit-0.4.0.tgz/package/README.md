# @possibl/rcrt-app-kit

React application framework for [RCRT](https://github.com/possibl-ai/rcrt-v2)
apps. Extracted from the production MSP console: you author **an app
definition** (the Section Registry) plus your domain components, and the
kit derives everything else — router, nav, the `interpret:ui-manifest`
App Control contract, advisor dock + spotlight, page-context grounding,
form prefill plumbing and cached-data chrome.

```
@possibl/rcrt-app-kit/core    platform-agnostic runtime (RN-safe): SWR cache,
                              tenant fan-out, breadcrumb schema helpers
@possibl/rcrt-app-kit/shell   web shell: defineSection/defineApp registry,
                              <RcrtApp>, advisor dock/bus/overlay, manifest
@possibl/rcrt-app-kit/native  React Native + Expo Router shell: interprets the
                              SAME registry, AsyncStorage SWR, chat-first advisor
@possibl/rcrt-app-kit/ui      web primitives + `--rcrt-*` design tokens
@possibl/rcrt-app-kit/styles.css
```

## Install

```bash
npm install @possibl/rcrt-app-kit @possibl/rcrt-sdk
# peers: react react-dom react-router-dom zustand
```

## The one rule

**Anything declared twice will eventually disagree.** Every
cross-cutting fact about a section — route, nav entry, anchors, forms,
page context, data chrome — is declared once in `defineSection()`, and
the manifest, router, nav, spotlight anchors and advisor grounding are
projections of it. The four classic wiring bugs (declared anchors with
no DOM, ambiguous form routing, forgotten page context, hand-rolled
cache ceremony) become structurally impossible:

- **Anchors are components, not strings.** `defineAnchor` returns a
  handle whose only render path is `<anchors.foo.Anchor>`; the
  namespaced id (`finance.ar`) is assigned by the registry and the
  manifest lists exactly the anchors that can render. A declared-but-
  unreferenced anchor is an unused variable (`noUnusedLocals`).
- **Forms have namespaced ids + structured semantics.** `intent`,
  `entity` and `distinguishFrom` are first-class manifest fields, not
  free prose; prefills are validated against declared field specs.
- **Page context is computed by the shell** on every location change
  (`{sectionId}:{tab}` by default, `context()` to override). Pages
  cannot set it, so they cannot forget it.
- **Cache ceremony is rendered by the shell.** `SectionPage cache={…}`
  gives every page the refresh button, `UpdatedAgo` honesty chip,
  error banner and `FanoutWarning` for free.

## Quickstart

A complete 2-section app is in
[`examples/basic/app.tsx`](./examples/basic/app.tsx) — 92 lines. The
skeleton:

```tsx
import { RcrtClient } from '@possibl/rcrt-sdk';
import { SwrCache, SwrProvider } from '@possibl/rcrt-app-kit/core';
import { defineApp, defineSection, RcrtApp, localStorageAdapter } from '@possibl/rcrt-app-kit/shell';
import '@possibl/rcrt-app-kit/styles.css';

const overview = defineSection({
  id: 'overview', path: '/overview', label: 'Overview',
  component: OverviewSection,          // your domain UI — real code, slotted in
});

const app = defineApp({
  name: 'my-app', version: '1.0.0',
  branding: { productName: 'My Console' },
  advisor: { suggestions: ['What needs my attention?'] },
  sections: [overview],
});

<BrowserRouter>
  <SwrProvider cache={new SwrCache({ storage: localStorageAdapter() })} scope={userScope}>
    <RcrtApp app={app} client={client} tenantId={tenantId} />
  </SwrProvider>
</BrowserRouter>
```

## Record routes, chromeless takeovers, nav badges (0.2)

A section is no longer first-path-segment only. It can declare **record
routes** — deep-linkable detail views — and opt out of the shell chrome
for full-bleed takeovers. A complete demo is in
[`examples/record-route/app.tsx`](./examples/record-route/app.tsx).

```tsx
const fleet = defineSection({
  id: 'fleet', path: '/fleet', label: 'Fleet', navGroup: 'Operate',
  component: Fleet,
  // Live nav badge (a component — it can use hooks; return null for none).
  navBadge: FleetBadge,
  records: {
    customer: {
      path: 'customers/:id',          // → /fleet/customers/:id
      component: CustomerRecord,       // props: { params, section, record, close }
      chrome: false,                   // full-bleed: no shell header, no nav rail
      // keepParentActive defaults true → Fleet stays highlighted while open.
      // Async page context: the URL has the id; resolve the NAME for grounding.
      context: async ({ params }) => `customer:${await nameOf(params.id)}`,
    },
  },
});
```

- **Record routes** project into the `ui-manifest` (route + anchors +
  forms) like any section, so the advisor can target them. `close()`
  navigates back to the parent section.
- **`chrome`** is `boolean | { header?, nav? }` on a section or record
  route — `false` is a full-bleed takeover; the advisor dock stays.
- **`context`** may be sync or `Promise`-returning, and receives record
  `params` — the shell awaits it and grounds the advisor when it resolves
  (no imperative `setPageContext` wiring).
- **`navSlot: 'top' | 'bottom'`** pins a nav entry into its own ungrouped
  block, so a home item and a settings item can both be ungrouped *and*
  separated. Omit it for the 0.1 grouping behavior.
- **`advisor.groundingTags(base)`** contributes extra grounding tags
  (e.g. a legacy `console-page:` mirror) to every message — no `sendChat`
  wrapper needed. Declare the prefixes in `contextTags` so the manifest
  advertises them.

All six are additive and opt-in: a 0.1 app's config compiles and behaves
unchanged.

## Auth is a seam

The kit never touches Firebase / Auth0 / Clerk. You configure an
`RcrtClient` with whatever `TokenProvider` your app uses and hand it to
`<RcrtApp>`. Templates wire the IdP; the kit stays clean.

## The advisor is inherited, not built

Every app gets the dock (collapsible right panel, ⌘J), guide-card
navigation, the spotlight overlay, `app-page:`/`app-context:` grounding
tags on every message, per-workspace session persistence, and paired-
bundle self-provisioning (`advisor.bundle`). The default chat surface
is the kit's minimal text chat; plug a full JIT-UI surface through
`advisor.renderChat`.

## Theming

All surfaces are driven by `--rcrt-*` CSS variables with a neutral
premium-dark default. Brand by overriding tokens — never by forking
components:

```css
:root {
  --rcrt-accent: #7c3aed;
  --rcrt-accent-2: #ec4899;
  --rcrt-gradient: linear-gradient(135deg, #7c3aed, #ec4899);
}
```

## React Native (`@possibl/rcrt-app-kit/native`)

A native app is authored as the **same `defineApp` / `defineSection`
config** the web shell consumes — the registry is platform-agnostic, and
`@possibl/rcrt-app-kit/native` interprets it with React Native + Expo
Router instead of the DOM + react-router-dom. `core` and the registry
itself are reused unchanged; that reuse is the proof.

```tsx
// app.config.ts — identical in SHAPE to the web template's
import { defineApp, defineSection } from '@possibl/rcrt-app-kit/native';
export const app = defineApp({ name: 'my-app', version: '0.1.0',
  branding: { productName: 'My App' }, sections: [home, items, settings],
  advisor: { suggestions: ['What needs my attention?'] } });

// app/_layout.tsx (Expo Router root)
import { Stack } from 'expo-router';
import { RcrtNativeProvider, asyncStorageAdapter } from '@possibl/rcrt-app-kit/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import EventSource from 'react-native-sse';
const storage = asyncStorageAdapter(AsyncStorage);
export default () => (
  <RcrtNativeProvider app={app} client={client} tenantId={tenantId}
                      storage={storage} eventSource={EventSource}>
    <Stack screenOptions={{ headerShown: false }} />
  </RcrtNativeProvider>
);

// app/(tabs)/_layout.tsx → <RcrtTabs app={app} />
// app/(tabs)/items.tsx   → <SectionScreen app={app} sectionId="items" />
// app/[section]/[id].tsx → <RecordScreen app={app} sectionId={s} recordKey="item" id={id} />
// app/advisor.tsx        → <AdvisorScreen />   (present as a modal)
```

**What is shared verbatim:** the registry (`defineSection`/`defineApp`/
`defineForm`), `core` (SWR + tenant fan-out + `defineSchema`), the
`interpret:ui-manifest` projection, page-context grounding, form prefill
plumbing and the advisor self-provisioning + grounding-tag contract.

**Honest RN-vs-web divergences:**

- **Spotlight is web-only.** The advisor `GuideOverlay` measures DOM
  anchors; that has no native equivalent, so the kit will not fake it.
  The native manifest sets `capabilities.spotlight = false` and the
  native `defineAnchor` is an honest pass-through (it keeps the anchor's
  id/label for advisor *grounding* but emits no measurement target).
  **Advisor-driven navigation (route push) DOES work on native** via
  Expo Router.
- **Navigation maps to Expo Router:** sections → bottom **tabs**, record
  routes → **stack** screens (deep-linkable), the advisor → a chat-first
  modal screen. A phone tab bar is flat, so `navGroup` doesn't apply;
  `navSlot: 'top'|'bottom'` still orders the tabs sensibly.
- **Domain bodies render `View`/`Text`, not DOM.** The kit ships native
  primitives (`Card`/`Badge`/`Button`/`SectionPage`/…) with the same
  names + prop shapes as `/ui`, so a section body reads the same on both
  platforms — but the body itself is platform-specific code (RN ≠ HTML).
  The shared, platform-agnostic surface is the **config + data layer**.
- **Storage is AsyncStorage** behind the same sync `StorageAdapter`
  (`asyncStorageAdapter` — sync-over-memory, hydrated from AsyncStorage).

**Peer deps for `/native`** (all optional — a web consumer never installs
them): `react-native`, `expo`, `expo-router`,
`@react-native-async-storage/async-storage`, `react-native-sse`.

A complete Expo + EAS template is `possibl-ai/rcrt-template-native`.

## Licence

MIT.
